package com.tibco.product.enums;

public class UserRoleEnum
{
	public enum UserRoleType
	{
		USER_ADMIN("admin")
		{
			@Override
			public int userRoleCode()
			{
				return 1;
			}
		}, 
		USER_NON_ADMIN("user")
		{
			@Override
			public int userRoleCode()
			{
				return 2;
			}
		};
		public abstract int userRoleCode();

		private final String value;

		UserRoleType(String value)
		{
			this.value = value;
		}
		public String getValue() 
		{
			return value;
		}
	}
	
	public static int getuserRoleCode(String key)
	{
		int value=0;
		for(UserRoleType enumKey : UserRoleType.values())
		{
			if(enumKey.getValue().equals(key))
				value = enumKey.userRoleCode();
		}
		return value;
	}

}
