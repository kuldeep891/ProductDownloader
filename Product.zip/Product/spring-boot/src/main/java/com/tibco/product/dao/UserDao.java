package com.tibco.product.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.tibco.product.model.User;

@Repository
public class UserDao {

	@Autowired
    JdbcTemplate jdbcTemplate;

	class UserRowMapper implements RowMapper <User> {
        @Override
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            User user = new User();
            user.setUserId(rs.getInt("user_id"));
            user.setUserName(rs.getString("user_name"));
            user.setUserPassword(rs.getString("password"));
            return user;
        }
    }
	
	public List <User> findAll() {
        return jdbcTemplate.query("select * from user_details", new UserRowMapper());
    }
	
	public int deleteById(Integer id) {
        return jdbcTemplate.update("delete from user_details where user_id=?", new Object[] {
            id
        });
    }

    public int insert(User user) {
        return jdbcTemplate.update("insert into user_details (user_id, user_name, password) " + "values(?, ?, ?)",
            new Object[] {
                user.getUserId(), user.getUserName(), user.getUserPassword()
            });
    }

    public int update(User user) {
        return jdbcTemplate.update("update user_details " + " set user_name = ?, password = ?" + " where user_name = ?",
            new Object[] {
            		user.getUserName(), user.getUserPassword(), user.getUserName()
            });
    }
}
