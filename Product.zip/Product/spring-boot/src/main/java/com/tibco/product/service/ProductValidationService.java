package com.tibco.product.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tibco.product.dao.UserDao;
import com.tibco.product.dao.UserRoleDao;
import com.tibco.product.enums.UserRoleEnum;
import com.tibco.product.model.User;
import com.tibco.product.model.UserRole;

@Service
public class ProductValidationService
{
	@Autowired
    UserRoleDao userRoleDao;
	@Autowired
	UserDao userDao;
    
	public int validateUser(String userName, String userPassword)
	{
		return userRoleDao.findRoleId(userName, userPassword);
	}
	
	public void createUser(User user, String role)
	{
		 userDao.insert(user);
		 System.out.println("Added User");
		 UserRole userRole = new UserRole();
         userRole.setUserId(userDao.findAll().stream().
        		 filter(x->(x.getUserName().equals(user.getUserName()))).findAny().get().getUserId());
		 userRole.setRoleId(UserRoleEnum.getuserRoleCode(role));
		 System.out.println(userRole.getRoleId());
		 userRoleDao.insert(userRole);
		 System.out.println("Added Role");
	}
	
	public void deleteUser(User user)
	{
		 userDao.deleteById(user.getUserId());
		 System.out.println("Deleted User");
	}
	
	public void updateUser(User user, String role)
	{
		 userDao.update(user);
		 System.out.println("Updated User");
		 UserRole userRole = new UserRole();
         userRole.setUserId(userDao.findAll().stream().
        		 filter(x->(x.getUserName().equals(user.getUserName()))).findAny().get().getUserId());
		 userRole.setRoleId(UserRoleEnum.getuserRoleCode(role));
		 System.out.println(userRole.getRoleId());
		 userRoleDao.update(userRole);
		 System.out.println("Updated Role");
	}
	
}
