package com.tibco.product.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.tibco.product.model.User;
import com.tibco.product.model.UserRole;

@Repository
public class UserRoleDao {

	
	@Autowired
    JdbcTemplate jdbcTemplate;

	class UserRoleRowMapper implements RowMapper <UserRole> {
        @Override
        public UserRole mapRow(ResultSet rs, int rowNum) throws SQLException {
        	UserRole userRole = new UserRole();
        	userRole.setUserId(rs.getInt("user_id"));
        	userRole.setRoleId(rs.getInt("role_id"));
            return userRole;
        }
    }
	
	
	public int findRoleId(String userName, String userPassword) {
		Optional<UserRole> userRole = Optional.of(jdbcTemplate.queryForObject("select a.role_id from user_role a, user_details b "
				+ "where a.user_id = b.user_id and b.user_name =? and b.password=?", new Object[] {
				userName, userPassword
            },
            new BeanPropertyRowMapper < UserRole > (UserRole.class)));
		if(userRole.isPresent())
		{
			return userRole.get().getRoleId();
		}
		else
			return -1;
    }
	
	public int insert(UserRole userRole) {
        return jdbcTemplate.update("insert into user_role (user_id, role_id) " + "values(?, ?)",
            new Object[] {
                userRole.getUserId(), userRole.getRoleId()
            });
    }
	
	public int update(UserRole userRole) {
        return jdbcTemplate.update("update user_role " + " set role_id = ?" + " where user_id = ?",
            new Object[] {
            		userRole.getRoleId(), userRole.getUserId()
            });
    }

}
