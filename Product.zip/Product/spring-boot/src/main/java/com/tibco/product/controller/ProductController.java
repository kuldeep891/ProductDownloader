package com.tibco.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tibco.product.model.User;
import com.tibco.product.service.ProductValidationService;

@Controller
public class ProductController {
 
	    @Autowired
	    ProductValidationService productValidationService;
	    
	    @GetMapping("getForm")
	    public String getForm() {
	        return "loginForm";
	    }
	    
	    @PostMapping("/showDetails")                     
	    public String showDetails(@RequestParam("userName") String userName,
	                              @RequestParam("userPassword") String userPassword) {
	        int roleId = productValidationService.validateUser(userName, userPassword);
	        if(roleId==1)
	        	return "viewAdminDetails";
	        else if(roleId==2)
	        	return "viewUserDetails";
	        else
	        	return "error";
	    }
	    
	    @GetMapping("/newUser")                     
	    public String createUserDetails() {
	        return "createUser";
	    }
	    
	    @PostMapping("/createUserDetailsInDB")                     
	    public String createUserDetailsInDB(@RequestParam("userNameDB")String userName, 
	    		@RequestParam("userPasswordDB")String userPassword, 
	    		@RequestParam("userRoleDB")String userRole) {
	    	User user = new User();
	    	user.setUserName(userName);
	    	user.setUserPassword(userPassword);
	    	productValidationService.createUser(user, userRole);
	        return "success";
	    }

	    @GetMapping("/deleteUser")                     
	    public String deleteUserDetails() {
	        return "deleteUser";
	    }
	    
	    @PostMapping("/deleteUserDetailsInDB")                     
	    public String deleteUserDetailsInDB(@RequestParam("userIdDB")int userId)
	    {
	    	User user = new User();
	    	user.setUserId(userId);
	    	productValidationService.deleteUser(user);
	        return "success";
	    }

	    
	    @GetMapping("/updateUser")                     
	    public String updateUserDetails() {
	        return "updateUser";
	    }
	    
	    @PostMapping("/updateUserDetailsInDB")                     
	    public String updateUserDetailsInDB(@RequestParam("userNameDB")String userName, 
	    		@RequestParam("userPasswordDB")String userPassword, 
	    		@RequestParam("userRoleDB")String userRole) {
	    	User user = new User();
	    	user.setUserName(userName);
	    	user.setUserPassword(userPassword);
	    	productValidationService.updateUser(user, userRole);
	        return "success";
	    }


}
