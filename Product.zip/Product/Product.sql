use product;

drop table user_role;
drop table user_role_ref;
drop table user_details;

create table user_details (
user_id int not null auto_increment = 100,
user_name varchar(50),
password varchar(1000),
constraint pk_user_details primary key (user_id));

alter table user_details auto_increment=100;

create table user_role_ref (
role_id int,
role_name varchar(50),
constraint pk_user_role_ref primary key (role_id));

create table user_role (
user_id int,
role_id int,
constraint pk_user_role primary key (user_id),
constraint fk_role_id foreign key(role_id) references user_role_ref(role_id),
constraint fk_user_id foreign key(user_id) references user_details(user_id) on delete cascade
);




insert into user_role_ref
select 1, 'admin' from dual;
insert into user_role_ref
select 2, 'user' from dual;

insert into user_details
select 100, 'admin','absfsfd12421##' from dual;
insert into user_details
select 101, 'user1','absfsfd12421##' from dual;
insert into user_details
select 102, 'user2','absfsfd12421##' from dual;



insert into user_role
select 100, 1 from dual;
insert into user_role
select 101, 2 from dual;

commit;



